from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'students', views.StudentViewSet, basename='student')

urlpatterns = [
    path('', include(router.urls)),
    path('students/all/', views.get_all_students, name='get-all-students'),
    path('student/create/', views.create_student, name='create-student'),
    path('student/<int:pk>/', views.get_student, name='get-student'),
    path('student/<int:pk>/delete/', views.delete_student, name='delete-student'),
]
